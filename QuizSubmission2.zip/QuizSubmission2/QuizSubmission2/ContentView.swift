//
//  ContentView.swift
//  Quiz4 Pt 3
//
//  Created by Karthik Ponnapalli on 4/9/23.
//


import SwiftUI
import OpenAIKit

final class ViewModel: ObservableObject {
    private var openai: OpenAI?

    func setup() {
        self.openai = OpenAI(Configuration(
            organizationId: "Personal",
            apiKey: "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"
        ))
    }

    func analyzeSentiment(text: String) async -> Double? {
        guard let openai = openai else {
            return nil
        }
        do {
            let prompt = "Classify the sentiment in this text:\n\"\(text)\".\nSentiment:"
            let completionParameter = CompletionParameters(
                model: "text-davinci-003",
                prompt: [prompt],
                maxTokens: 60,
                temperature: 0)
            let completionResponse = try await openai.generateCompletion(
                parameters: completionParameter
            )
            let sentiment = completionResponse.choices.first?.text.lowercased()
            switch sentiment {
            case "positive":
                return 1.0
            case "negative":
                return -1.0
            case "neutral":
                return 0.0
            default:
                return nil
            }
        } catch {
            print(String(describing: error))
            return nil
        }
    }
}

struct ContentView: View {
    @ObservedObject var viewModel = ViewModel()
    @State var text = ""
    @State var sentimentResult: Double?

    var body: some View {
        VStack {
            TextField("Enter text here...", text: $text)
                .padding()
            Button("Analyze Sentiment") {
                if !text.trimmingCharacters(in: .whitespaces).isEmpty {
                    Task {
                        let result = await viewModel.analyzeSentiment(text: text)
                        if result == nil {
                            print("failed to analyze sentiment")
                        }
                        self.sentimentResult = result
                    }
                }
            }
            Spacer()
            if let sentiment = sentimentResult {
                Text("Sentiment: \(sentiment == 1.0 ? "Positive" : sentiment == -1.0 ? "Negative" : "Neutral")")
                    .padding()
            }
        }
        .navigationTitle("OpenAI Sentiment Analysis")
        .onAppear {
            viewModel.setup()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
