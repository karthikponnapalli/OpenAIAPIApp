//
//  ContentView.swift
//  Quiz4 Q2
//
//  Created by Karthik Ponnapalli on 4/9/23.
//

import SwiftUI
import OpenAIKit

final class ViewModel: ObservableObject {
    private var openai: OpenAI?
    
    func setup() {
        self.openai = OpenAI(Configuration(
            organizationId: "Personal",
            apiKey: "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"
        ))
    }

    func completeSentence(prompt: String) async -> String? {
        guard let openai = openai else {
            return nil
        }
        do {
            let completionParameter = CompletionParameters(
                model: "text-davinci-001",
                prompt: [prompt],
                maxTokens: 10,
                temperature: 0.98
            )
            let completionResponse = try await openai.generateCompletion(
                parameters: completionParameter
            )
            let responseText = completionResponse.choices[0].text
            return responseText
        } catch {
            print(String(describing: error))
            return nil
        }
        
        
        //        do {
        //            let params = ["engine": "davinci",
        //                          "prompt": prompt,
        //                          "max_tokens": 100] as Dictionary<String, Any>
        //
        //
        //
        //            let result = try await openai.createCompletion(model: "davinci", parameters: params)
        //
        //            return result.choices.first?.text
        //
        //        } catch {
        //            print(String(describing: error))
        //            return nil
        //        }
        
    }

}







struct ContentView: View {
    @ObservedObject var viewModel = ViewModel()
    @State var text = ""
    @State var completionResult = ""

    var body: some View {
        VStack {
            TextField("Type incomplete sentence here...", text: $text)
                .padding()
            Button("Complete") {
                if !text.trimmingCharacters(in: .whitespaces).isEmpty {
                    Task {
                        let result = await viewModel.completeSentence(prompt: text)
                        if result == nil {
                            print("failed to complete sentence")
                        }
                        self.completionResult = result ?? ""
                    }
                }
            }
            Spacer()
            Text(completionResult)
                .padding()
        }
        .navigationTitle("OpenAI Sentence Completion")
        .onAppear {
            viewModel.setup()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
