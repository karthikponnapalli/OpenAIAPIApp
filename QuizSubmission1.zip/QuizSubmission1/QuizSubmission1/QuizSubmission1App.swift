//
//  Quiz4App.swift
//  Quiz4
//
//  Created by Karthik Ponnapalli on 4/9/23.
//

import SwiftUI

@main
struct Quiz4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
