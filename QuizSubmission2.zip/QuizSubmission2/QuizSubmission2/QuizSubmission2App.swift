//
//  Quiz4_Pt_3App.swift
//  Quiz4 Pt 3
//
//  Created by Karthik Ponnapalli on 4/9/23.
//

import SwiftUI

@main
struct Quiz4_Pt_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
