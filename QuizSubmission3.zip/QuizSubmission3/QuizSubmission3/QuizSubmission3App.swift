//
//  Quiz4_Q2App.swift
//  Quiz4 Q2
//
//  Created by Karthik Ponnapalli on 4/9/23.
//

import SwiftUI

@main
struct Quiz4_Q2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
